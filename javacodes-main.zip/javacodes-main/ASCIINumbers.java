
public class ASCIINumbers {
	public static void main(String[] args)
	{
		
		for(char c = 'A'; c <= 'Z'; c++ ) {
			System.out.println("ASCII value of "+ c +": " +(int) c);
			
		}
		
		
		
		
	}
}
