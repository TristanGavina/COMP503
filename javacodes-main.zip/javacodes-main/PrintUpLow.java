
public class PrintUpLow {
	
	public static void main(String[] args){
        for (char c = 'a'; c <= 'z'; c++) {
        	System.out.println(c + "" + Character.toUpperCase(c));
        	
        }

		
		
		
		
	}
}
