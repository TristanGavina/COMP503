
public class PrintEvenNumbers {
	public static void main(String[] args)
	{
		for (int i = 20; i <= 40; i++ ) {
			if ( i % 2 == 0) {
				System.out.println(i);
			}
		}
	}
	
}
