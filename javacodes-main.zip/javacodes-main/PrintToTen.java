public class PrintToTen {

	public static void main(String[] args) {
		
		int number = 0;
		while (++number <= 10) {
            System.out.printf("number = %d%n", number);
        }
	}

}
