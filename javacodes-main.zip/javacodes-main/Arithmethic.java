
public class Arithmethic {
	public static void main(String[] args) {
		int x = 5;
		int y = 3;
		int sum = x + y;
		int product = x * y;
		int mod = x % y;
		System.out.println("x = "+x);
		System.out.println("y = "+y);
		System.out.println("sum = "+sum);
		System.out.println("product = "+product);
		System.out.println("mod = "+mod);
		
	}
}
