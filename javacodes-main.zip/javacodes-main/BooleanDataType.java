
public class BooleanDataType {
	public static void main(String[] args)
	{
		boolean isRaining = true;
		boolean isOutside = false;
		System.out.println("isRaining = "+isRaining);
		System.out.println("isOutside = "+isOutside);
		boolean andResult = false;	
		boolean orResult = true;
		boolean notResult = true;
		System.out.println("andResult = "+andResult);
		System.out.println("orResult = "+orResult);
		System.out.println("notResult = "+notResult);

		
	}
}
