public class Relations {
	public static void main(String[] args) {
		int x = 2;
		int z = 8;
		System.out.println("x =" +x);
		System.out.println("z =" +z);
		System.out.println("" + (x == z));
		System.out.println("" + (x != z));
		System.out.println("" +(x > z));
		System.out.println("" + (x < z));
		System.out.println("" + (x >= z));
		
	
		
	}
}
