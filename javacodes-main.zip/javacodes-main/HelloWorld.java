
public class HelloWorld 
{
	public static void main (String[] args) {
		System.out.println("Hello World");
		int productcost = 16;
		System.out.println(productcost);	
		String greeting = "Hello Ken";
		System.out.println(greeting);
	}
}
