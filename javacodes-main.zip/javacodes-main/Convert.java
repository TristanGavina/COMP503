public class Convert {
    public static void main(String args[]) 
    {
        char four = '5'- 1;
		char letter = 'C' - 2;
		System.out.println("four = "+four);
		System.out.println("letter = "+letter);
		int fourValue = four;
		int letterValue = letter;

		System.out.println("fourValue = "+fourValue);
		System.out.println("letterValue = "+letterValue);
    }
}
