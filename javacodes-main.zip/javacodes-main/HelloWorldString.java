
public class HelloWorldString {
	public static void main (String [] args) {
		String s = "Hello World!";
		System.out.println("s = "+s);
		System.out.println("len = "+s.length());
		char ch = s.charAt(6);
		System.out.println("ch = "+s.charAt(6));
	}
	
}
