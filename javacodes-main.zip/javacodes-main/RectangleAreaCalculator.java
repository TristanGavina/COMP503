public class RectangleAreaCalculator 
{
	public static void main(String [] args)
	{
		int length = 5;
		int width = 3;
		int area = length * width;
		System.out.println("area ="+area);			
	}
}