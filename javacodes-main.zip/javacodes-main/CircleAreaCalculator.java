
public class CircleAreaCalculator {
	public static void main(String[] args) {
		double radius = 10.5;
		double area = Math.PI * radius * radius;
		System.out.println("area = "+area);
	}
}
